<script setup></script>

<template>
  <div class="min-h-screen bg-gray-800">
    <router-view></router-view>
  </div>
</template>
