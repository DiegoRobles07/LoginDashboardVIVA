<template>
  <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 p-4 bg-white rounded-lg shadow">
    <!-- Buscar fechas -->
    <div>
      <label class="block text-sm font-medium text-black">Buscar fechas</label>
      <DatePicker v-model="localFilters.dateRange" selection-mode="range" placeholder="Selecciona rango de fechas"
        class="mt-1 block w-full h-10 border border-gray-300 rounded-lg shadow-sm"
        input-class="h-10 w-full text-center text-sm rounded-lg" />
    </div>

    <!-- Horario -->
    <div>
      <label class="block text-sm font-medium text-black">Horario</label>
      <input type="text" v-model="scheduleQuery" placeholder="Buscar horario..."
        class="mt-1 block w-full h-10 border border-gray-300 rounded-lg shadow-sm" />
    </div>

    <!-- Equipo -->
    <div>
      <label class="block text-sm font-medium text-black">Equipo</label>
      <input type="text" v-model="teamQuery" placeholder="Buscar equipo..."
        class="mt-1 block w-full h-10 border border-gray-300 rounded-lg shadow-sm" />
    </div>

    <!-- Llegadas tardías -->
    <div>
      <label class="block text-sm font-medium text-black">Llegadas tardías</label>
      <div class="flex items-center gap-2 mt-2">
        <input type="checkbox" v-model="localFilters.lateArrivals"
          class="mx-11 h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
      </div>
    </div>

    <!-- Botones -->
    <div class="col-span-1 lg:col-span-4 flex justify-end gap-4 mt-4">
      <button type="button" @click="emitFilters"
        class="px-5 py-2 bg-black text-white rounded-lg shadow hover:bg-gray-800">
        Buscar
      </button>
      <button type="button"
        class="px-5 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-800 disabled:opacity-50"
        :disabled="selectedEmployees.length === 0">
        Modificar
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import DatePicker from "primevue/datepicker";

defineProps({
  selectedEmployees: { // Prop que recibe los empleados seleccionados
    type: Array,
    default: () => [],
  },
});

const emit = defineEmits(["filter-change"]);

const localFilters = ref({
  dateRange: null,
  lateArrivals: false,
});

const scheduleQuery = ref("");
const teamQuery = ref("");

const emitFilters = () => {
  emit("filter-change", localFilters.value);
};
</script>