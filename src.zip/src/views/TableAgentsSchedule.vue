<template>
    <div class="mt-3">
        <!-- DataTable -->
        <DataTable :data="filteredData" :selected-employees="selectedEmployees"
            @update-selected="updateSelectedEmployees" @edit-agent="openModal" />

        <!-- Modal -->
        <div v-if="showModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                <h2 class="text-xl font-bold mb-4">Editar Información del Agente</h2>

                <!-- Información del agente -->
                <p class="mb-2">Nombre: {{ selectedAgent.nombre }}</p>
                <p class="mb-2">Grupo: {{ selectedAgent.grupo }}</p>
                <p class="mb-2">Semana: {{ selectedAgent.semana }}</p>
                <p class="mb-4">Día: {{ selectedAgent.dia }}</p>

                <!-- Subir imagen -->
                <div class="mb-4">
                    <label class="block text-sm font-medium">Subir Incapacidad</label>
                    <input type="file" @change="onFileChange" accept="image/*" />
                    <img v-if="previewImage" :src="previewImage" class="mt-2 rounded-lg max-h-32" />
                </div>

                <!-- Botones del modal -->
                <div class="flex justify-end gap-2">
                    <button @click="closeModal" class="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400">
                        Cancelar
                    </button>
                    <button @click="saveChanges" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-800">
                        Guardar
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, computed } from "vue";
import DataTable from "../components/DataTable.vue";

// Datos falsos (fake data)
const tableData = ref({
    semanas: [
        {
            numero: 48,
            dias: ["Do-01", "Lu-02", "Ma-03", "Mi-04", "Ju-05", "Vi-06", "Sa-07"],
            empleados: [
                { grupo: "Admins", nombre: "Anthony Vasquez", minutos: [143, 13, 10, 15, 1440, 9, 1440], totalSemanal: 2914 },
                { grupo: "Admins", nombre: "Diego Robles", minutos: [1440, 1440, 1440, 1440, 1440, 1440, 1440], totalSemanal: 10080 },
            ],
        },
        {
            numero: 49,
            dias: ["Do-08", "Lu-09", "Ma-10", "Mi-11", "Ju-12", "Vi-13", "Sa-14"],
            empleados: [
                { grupo: "Customer Services", nombre: "Jocelyn Santos", minutos: [0, 0, 0, 2, 553, 0, 0], totalSemanal: 555 },
            ],
        },
    ],
    totalMensual: [
        { empleado: "Anthony Vasquez", total: 3057 },
        { empleado: "Diego Robles", total: 10080 },
        { empleado: "Jocelyn Santos", total: 555 },
    ],
});

// Estados y referencias
const selectedEmployees = ref([]); // Empleados seleccionados
const showModal = ref(false); // Mostrar modal
const selectedAgent = ref({}); // Agente seleccionado
const previewImage = ref(""); // Imagen subida

// Filtros de datos
const filters = ref({});
const filteredData = computed(() => tableData.value);

// Actualizar empleados seleccionados
const updateSelectedEmployees = (selected) => {
    selectedEmployees.value = selected;
    console.log("Empleados seleccionados:", selectedEmployees.value);
};

// Abrir modal al hacer clic en una celda
const openModal = (agent) => {
    selectedAgent.value = agent;
    showModal.value = true;
};

// Cerrar modal
const closeModal = () => {
    showModal.value = false;
    previewImage.value = "";
};

// Subir imagen
const onFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => (previewImage.value = event.target.result);
        reader.readAsDataURL(file);
    }
};

// Guardar cambios en el modal
const saveChanges = () => {
    console.log("Guardando cambios del agente:", selectedAgent.value);
    closeModal();
};

// Lógica para el botón Modificar
const handleModify = () => {
    console.log("Modificar empleados seleccionados:", selectedEmployees.value);
};
</script>
