<template>
    <div v-if="show" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h2 class="text-lg font-semibold mb-4">Editar Día</h2>
            <form @submit.prevent="onSave">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Empleado</label>
                    <input type="text" v-model="dataProxy.employee" disabled
                        class="block w-full border-gray-300 rounded-md shadow-sm mt-1" />
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Día</label>
                    <input type="text" v-model="dataProxy.day" disabled
                        class="block w-full border-gray-300 rounded-md shadow-sm mt-1" />
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Minutos</label>
                    <input type="number" v-model="dataProxy.minutes"
                        class="block w-full border-gray-300 rounded-md shadow-sm mt-1" />
                </div>
                <div class="flex justify-end gap-4">
                    <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Guardar</button>
                    <button type="button" @click="$emit('close')"
                        class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</template>

<script setup>
import { defineProps, defineEmits, computed } from 'vue';

defineProps({
    show: Boolean,
    data: {
        type: Object,
        default: () => ({ employee: '', day: '', minutes: 0 }),
    },
});

defineEmits(['close', 'save']);

// Computed proxy to handle default values without breaking v-model
const dataProxy = computed(() => ({
    employee: data.employee || '',
    day: data.day || '',
    minutes: data.minutes || 0,
}));

function onSave() {
    // Emitimos el evento save con los datos editados
    emit('save', dataProxy.value);
}
</script>

<style scoped>
/* Estilos opcionales para el modal */
</style>